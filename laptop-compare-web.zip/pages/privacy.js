
export default function Privacy() {
  return <div><h1>Privacy Policy</h1><p>No personal data collected.</p></div>;
}
