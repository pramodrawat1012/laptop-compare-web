
export default function Terms() {
  return <div><h1>Terms of Service</h1><p>Informational comparison only.</p></div>;
}
