
export default function Home() {
  return (
    <main>
      <h1>Laptop Comparison</h1>
      <p>Search and compare laptops anonymously.</p>
    </main>
  );
}
